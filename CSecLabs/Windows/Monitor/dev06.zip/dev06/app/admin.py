from django.contrib import admin
from .models import MainUser

# Register your models here.
admin.site.register(MainUser)
